<?php
class Test{
	public function index(){
		$data = array('prabha'=>"php developer");
		echo Http::json($data);
	}
	public function delete(){
		echo Http::body()->username;
	}
}