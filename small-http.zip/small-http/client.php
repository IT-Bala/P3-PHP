<?php
define("BASE_URL","http://localhost/practice/small-http/");
class client{
	public function client(){
		define("SH_KEY","API");
		define("SH_VALUE","SH");
	}
	public function curl_post($url,$post_fields=array(),$json=false){   # true means direct json format print || false means object oriented format      
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$post_fields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
                'Content-Type: application/json',                                                                                
                SH_KEY.': '.SH_VALUE)                                                                      
            );
            $server_output = curl_exec ($ch);
            curl_close ($ch);
            if($json==true){
                return $server_output;
            }else{
                return json_decode($server_output);
            }
     }      
       
     public function curl_get($url,$json=false){            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
                'Content-Type: application/json',                                                                                
                SH_KEY.': '.SH_VALUE)                                                                       
            );
            $server_output = curl_exec($ch);
            curl_close ($ch);
             if($json==true){
                return $server_output;
            }else{
                return json_decode($server_output);
            }
     }
	 public function curl_put($url,$post_fields,$json=false){            
            $ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
			curl_setopt($ch, CURLOPT_POSTFIELDS,$post_fields);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
                'Content-Type: application/json',                                                                                
                SH_KEY.': '.SH_VALUE)                                                                       
            );
			$response  = curl_exec($ch);
			curl_close($ch);      
             if($json==true){
                return $server_output;
            }else{
                return json_decode($server_output);
            }
       }
	 public function curl_delete($url,$post_fields,$json=false){            
            $ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($ch, CURLOPT_POSTFIELDS,$post_fields);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
                'Content-Type: application/json',                                                                                
                SH_KEY.': '.SH_VALUE)                                                                       
            );
			$response  = curl_exec($ch);
			curl_close($ch);          
             if($json==true){
                return $server_output;
            }else{
                return json_decode($server_output);
            }
       }
}

$url 		 = BASE_URL.'nodejs';
$post_fields = array();
$rest = new client();
echo $rest->curl_post($url,[],true);