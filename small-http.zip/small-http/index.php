<?php
require_once 'Http.php';

$app = new Http();

$app->get('/',function($app){
	echo "Welcome to home page";
});

$app->post('/php',function($app){
	echo "Welcome to post php";
});

$app->get('/testing/php',function($app){
	#echo "Testing php is running...";
	$app->html('test.php');
});

$app->get('/java',function($app){
	echo "Welcome to java";
});

$app->get('/net',function($app){
	echo "Welcome to .NET";
});

$app->get('/php',function($app){
	echo "Welcome to get php";
	echo '<form method="post" action="php"><input type="submit" value="Submit"></form>';
});

$app->get('/php/bala',function($app){
	echo "Welcome to php-bala";
});

$app->get('/python',function($app){
	echo "Welcome to python";
});

$app->get('/ruby',function($app){
	echo "Welcome to ruby";
});

$app->get('/nodejs',function($app){
	echo "Welcome to nodejs";
});

$app->run();