<?php
#==============================================#
define("SHA",true); # Small Http Authentication [Don't remove it]
#==============================================#
define("SH_KEY","API");
define("SH_VALUE","SH");

require_once 'Http.php';

$app = new Http();

$app->get('/',function($app){
	echo "Welcome to SH Rest";
});

$app->post('/php',function($app){
	$data = array("Framework"=>"Small-Http");	
	echo $app->json($data);
				
});

$app->post('/nodejs',function($app){
	$data = array("Nodejs"=>"Small-Http Nodejs");	
	echo $app->json($data);			
});

$app->get('/php',function($app){
	#print_r($_SERVER);		
	echo '<form method="post" action="php"><input type="submit" value="Submit"></form>';
});

$app->get('/nodejs',function($app){
	echo $app->json(["nodejs"=>"Good"]);
});

$app->run();