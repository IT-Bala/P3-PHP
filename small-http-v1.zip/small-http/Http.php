<?php
if(!defined("SHA")) die("Access denied!");
require_once 'dbc/dbc.php';
require_once 'config.php';
class Http{ var $http_method; public $db;
	public function Http(){ #set_error_handler('getError');
		$this->http_method = $_SERVER['REQUEST_METHOD'];
		$this->html_path   = 'html';
		$this->db = new dbc([
			'database_type' => DATABASE_TYPE,
			'database_name' => DATABASE,
			'server' => HOST,
			'username' => USERNAME,
			'password' => PASSWORD,
			'charset' => 'utf8'
		]);
	}
	public function __call($name,$args){
		die('<p align="center">Error : '.$name.'() method is invalid');
	}
	public function get($target=NULL,$callback=NULL){
		$argUrl = (filter_var($target, FILTER_SANITIZE_URL));
		if($this->http_method == 'GET') self::switchPage($argUrl,$callback);
	}
	public function post($target=NULL,$callback=NULL){
		$argUrl = (filter_var($target, FILTER_SANITIZE_URL));
		if($this->http_method == 'POST') 
		self::switchPage($argUrl,$callback);
	}
	public function put($target=NULL,$callback=NULL){
		$argUrl = (filter_var($target, FILTER_SANITIZE_URL));
		if($this->http_method == 'PUT') self::switchPage($argUrl,$callback);
	}
	public function delete($target=NULL,$callback=NULL){
		$argUrl = (filter_var($target, FILTER_SANITIZE_URL));
		if($this->http_method == 'DELETE') self::switchPage($argUrl,$callback);
	}
	private function setHeader($status,$body=""){
		if($status!=""){
			header("HTTP/1.1 ".$status."");
			header("Content-Type: application/json");
			return json_encode(["status"=>$status,"body"=>$body]);
		}
	}
	private function response(){
		// set headder & status
		
	}
	public function json($content){
		// application/json
		return $this->setHeader("200",$content);
	}
	
	private function error(){
		
	}
	private function getCurrentUri(){
		$basepath = implode('/', array_slice(explode('/', $_SERVER['SCRIPT_NAME']), 0, -1)) . '/';
		$uri = substr($_SERVER['REQUEST_URI'], strlen($basepath));
		if (strstr($uri, '?')) $uri = substr($uri, 0, strpos($uri, '?'));
		$uri = '/' . trim($uri, '/');
		return $uri;
	}
	private function switchPage($argUrl,$callback){
		$this->routes[$this->http_method][] = $argUrl;
		switch($argUrl){
			case self::getCurrentUri():
				if($callback!=NULL) $this->access = $callback;
			break;
			default:
			
		}
	}
	public function run(){
		switch($this->http_method){
			case ('GET' || 'POST' || 'PUT' || 'DELETE'):
				if(in_array(self::getCurrentUri(),$this->routes[$this->http_method])){
				  if((isset($_SERVER['HTTP_'.SH_KEY]) && $_SERVER['HTTP_'.SH_KEY] == SH_VALUE) || SHA==FALSE){
						$call = $this->access;
						$call( new Http() );
				  }else{
						die($this->setHeader("401","Unauthorized"));
					}
				}else{
						die($this->setHeader("400","Bad Request"));
				}
			break;
			default:
			
		}
		
	}
	public function html(){ $args = func_get_args();
			if(count($args)>0 && $args[0]!=''){
				$file = $this->html_path.'/'.$args[0];
				if(file_exists($file)) require $file;
			}
	}
}
function getError($number, $msg, $file, $line, $vars){
	   $error = debug_backtrace(); #var_dump($error);
	   $msg = '<pre><div style="margin:auto;"><p align="center">File : '.$error[0]['file'].'<br>';
	   $msg .= 'Line : '.$error[0]['line'].'<br>';
	   $msg .= 'Error : '.$error[0]['args'][1].'</div></p></pre>';
	   die($msg);
}