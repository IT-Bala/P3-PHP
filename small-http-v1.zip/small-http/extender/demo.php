<?php
if(!defined("SHA")) die("Access denied!");
Http::get('/sha',function($app){ 
	$q = $app->db->query("select * from tbl_users")->fetchAll();
	#echo $app->json($q);
	echo ab();
});

Http::routes('GET /sh',['a'=>'User::insert']);

