<?php
#==============================================#
define("SHA",false); # Small Http::SH Authentication [Don't remove it]
#==============================================#
require_once 'Http.php';

$app = new Http();

$app->get('/',function($app){ echo $app->json(["Welcome to SH server"]); });

$app->get('/test',function($app){
	 $q = $app->db->select('tbl_users','*');
	 echo $app->json($q);
});

#$app->library('Demo')->a();

$app->routes('GET/user',
	['insert'=>function($app){ echo $app->json(['welcome']); },'update'=>'User::insert','edit'=>'']
	);


$app->run(['demo']); # Extender