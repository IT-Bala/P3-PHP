<?php
#==============================================#
define("SHA",true); # Small Http Authentication [Don't remove it]
#==============================================#

require_once 'Http.php';

$app = new Http();

$app->get('/',function($app){
	echo "Welcome to SH Rest";
});

$app->post('/user/insert',function($app){
	
	$id = $app->db->insert('tbl_users', [
		'username' => 'foo',
		'email' => 'foo@bar.com',
		'address' => 'adyar',
	]);
	print_r($id);
	
});

$app->post('/upload',function($app){ $data = array();	
	$response = $app->body();
	if($response->username && $response->photo != NULL){
		$file_path = "uploads/".time();
		$app->create_file($file_path,$response->photo);
		$data = array("message"=>"success");	
	}	
	echo $app->json($data);
});

$app->get('/prabha',function($app){
	$data = array('prabha'=>"php developer");
	echo $app->json($data);
});

$app->get('/users',function($app){
	$data = $app->db->select('tbl_users','*');
	
	echo $app->json($data);			
});

$app->run();