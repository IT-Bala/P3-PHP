<?php
define("BASE_URL","http://localhost/practice/small-http/");
define("SH_KEY","API");
define("SH_VALUE","SH");

require_once 'Curl.php';

$url 		 = BASE_URL.'prabha';
$post_fields = array();
#$rest = new Curl();
echo Curl::get($url,true);