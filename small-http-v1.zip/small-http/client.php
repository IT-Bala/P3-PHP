<?php
define("BASE_URL","http://localhost/practice/small-http/");
define("SH_KEY","API");
define("SH_VALUE","SH");

require_once 'Curl.php';

$url 		 = BASE_URL.'users';
$post_fields = array();
#$rest = new Curl();
#echo Curl::get($url,true);

if(isset($_POST['submit'])){
	$url 		 = BASE_URL.'upload';
	
	$filename = $_FILES['photo']['name'];
	$tmp = $_FILES['photo']['tmp_name'];
	$type = pathinfo($filename, PATHINFO_EXTENSION);
	$data = file_get_contents($tmp);
	$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
	
	$result 	  = array(
						"username"=>$_POST['username'],
						"photo"=>$base64
					);
	echo Curl::post($url,json_encode($result),true);
}
?>
<form method="post" enctype="multipart/form-data">
<input type="file" name="photo" />
<input type="text" name="username" />
<input type="submit" name="submit" />
</form>