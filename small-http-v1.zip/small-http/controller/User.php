<?php
class User{ 
	public function __construct(){
		$this->app = new Http;
		$this->name = 'Small-Http';
	}
	public function insert(){
		#echo "Hello, {$this->name}!";
		$this->app->library('Demo')->a();
	}	
	public function update(){
		echo 'Update';
	}
	public function delete(){
		Http::model('Test')->delete();
	}
}