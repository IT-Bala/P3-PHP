<?php
define("SH_KEY","API");
define("SH_VALUE","SH");

#=================================#
/* DATABASE */
define("HOST","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","3p-php");
define("DATABASE_TYPE","mysql");