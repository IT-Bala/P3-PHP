<?php
define("SH_KEY","API");
define("SH_VALUE","SH");

/* CONTROLLER */
#=================================#
define("CONTROLLER_PATH","controller/");
define("MODEL_PATH","model/");
define("HTML_PATH","html/");
define("LIBRARY_PATH","library/");
define("EXT_PATH","extender/");
#=================================#
/* DATABASE */
define("HOST","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","3p-php");
define("DATABASE_TYPE","mysql");
