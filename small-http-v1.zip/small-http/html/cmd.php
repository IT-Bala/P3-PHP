<style>
textarea#cmd{
  resize:none;
  background:#000;
  border:none;
  color:#FFF;
  overflow: hidden;
  width:100%;
  min-height:20px;
  font-size:18px;
  font-weight:bold;
  min-height:250px;
  padding:4px 0;
}
</style>
<textarea id="cmd"></textarea>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(e){
    $("textarea#cmd").val('SH: ');
});
/*
var lines = $('textarea').val().split('\n');
for(var i = 0;i < lines.length;i++){
    //code here using lines[i] which will give you each line
}
*/
$("textarea#cmd").keyup(function(event){
    if((event.keyCode || event.which) == 13){ //Enter keycode
		event.preventDefault();
	    var lines = $('textarea#cmd').val().split('\n');
		lines.splice(-1,1); // remove last empty array
		var last_line = lines[lines.length - 1];
		for(var i = 0;i < lines.length;i++){
			//console.log(lines[i]);
		}
		console.log(last_line);
	  
      $(this).val($(this).val()+'SH: ').focus();
	  // If done roll back
	  
	  //$(this).val('SH: ').focus();
    }
	if($(this).val().indexOf("SH: ") !== 0) {
        var length = "SH: ".length;
        var current = $(this).val();
        var after = current.slice(length);

        $(this).val("SH: " + after);
    }
});

</script>