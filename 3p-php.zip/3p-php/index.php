<?php
// configuration 3p-void
define("p3","true");
// BASE OF 3P-PHP
require "3p-base.php";