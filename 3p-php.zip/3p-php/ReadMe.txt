# DATABASE INSTRUCTION #
Updated News :

$this->db->query("select * from table"); # If __DBGLOBAL__ true

$db = $this->setDatabase(); # Loading DB
$db->query("select * from table");

# CONTROLLER IMPORTANT NOTES #

i.  If you use __construct on your controller : you should call parent::__construct();

	public function __construct(){
			parent::__construct();	
	}
ii. controller method should not be protected or private.