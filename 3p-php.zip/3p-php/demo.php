<?php
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start('ob_gzhandler'); else ob_start();
$db = new mysqli("localhost","root","","memcache");

#$db->query("LOAD DATA INFILE 'D:/xampp/htdocs/practice/3p-php/sample-csv-file.csv' INTO TABLE tbl_post");

#"LOAD DATA INFILE 'D:/xampp/htdocs/practice/3p-php/sample-csv-file.csv' IGNORE INTO TABLE tbl_post FIELDS TERMINATED BY ',' ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\n' (title, content)"

$db->query("LOAD DATA INFILE 'D:/xampp/htdocs/practice/3p-php/sample-csv-file.csv' IGNORE INTO TABLE tbl_post FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (title, content)");
 