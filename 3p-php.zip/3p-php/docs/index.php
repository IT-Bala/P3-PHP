<?php include_once 'header.php'; ?>
<!-- Page Heading -->

<div ng-view></div>

<?php include_once 'footer.php'; ?>