<?php
# Controller
if(!defined('p3')){ die("Access Denied!");}
class dataModel extends WLT_Model{
	public function data(){
 		return "This is data!"; 
	}
}
