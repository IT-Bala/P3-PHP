<?php
# Helper
function base_url(){  
	return "";
}
