<?php
# Library
class Date{
	public function today(){ 
		return date('Y-m-d');
	} 
}
