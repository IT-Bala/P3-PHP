<?php
if(!defined('p3')){ die("Access Denied!");}
# CONFIG VARIABLE #
$GLOBALS['CONFIG'] = array(
		"BASE_URL" => 'http://google.com'
);

$GLOBALS['CONFIG']['__DBGLOBAL__'] = 'true';
