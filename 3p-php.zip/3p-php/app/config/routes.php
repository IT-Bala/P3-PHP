<?php
if(!defined('p3')){ die("Access Denied!");}

# ROUTER SETTING #

$GLOBALS['defaultController'] = 'default'; # set controller name as home page;

$GLOBALS['defaultTheme']      = 'default'; # set theme folder name to activate theme;