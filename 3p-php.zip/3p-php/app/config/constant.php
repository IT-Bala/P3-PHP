<?php
if(!defined('p3')){ die("Access Denied!");}
# CONST VALUE DEFINE IN A VARIABLE