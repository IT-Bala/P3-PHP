<?php
# Controller
if(!defined('p3')){ die("Access Denied!");}
class DefaultController extends WLT_Controller{
	public function __construct(){
		parent::__construct();
		#$this->setHelper('url');
	}
	public function index(){ 
		$data['title'] = 'P3-PHP is the small foot print!';
		$data['products'] = $this->setModel('testModel')->test();
		#echo $this->get('edit');
		#$this->setHtml('section/header',$data);
		#$this->setHtml('index',$data);
		#$this->setHtml('section/footer',$data);
		$this->db = $this->setDatabase();
		$sql = $this->db->query("select * from tbl_users");
		while($obj = $sql->fetch_object()){ 
			$data['users'][] = $obj;
		}
		
		$this->setHtml('section/header',$data)->setHtml('index',$data)->setHtml('section/footer');
		
	}
	public function test($args){
		$data['title'] = "This test page";
		$obj = $this->setModel('testModel');
		$data['ramesh'] = $obj->ramesh();
		$data['products'] = $obj->test();
		$this->setHtml('section/header',$data);
		$this->setHtml('test',$data);
		$this->setHtml('section/footer',$data);
	}
	public function aboutus(){
		$this->setHtml('aboutus');
	}
}