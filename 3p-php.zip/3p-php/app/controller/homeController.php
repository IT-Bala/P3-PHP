<?php
# Controller
if(!defined('p3')){ die("Access Denied!");}
class HomeController extends WLT_Controller{
	public function index(){		
		$this->sethtml('section/header');
			echo "Welcome to home page!";
		$this->sethtml('section/footer');
	}
}
