<?php
# Controller
if(!defined('p3')){ die("Access Denied!");}
class TestController extends WLT_Controller{
	public function index(){
		echo "Test is running...";
	}
}
