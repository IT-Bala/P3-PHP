<?php
if(!defined('p3')){ die("Access Denied!");}
class privateController{
	
} 