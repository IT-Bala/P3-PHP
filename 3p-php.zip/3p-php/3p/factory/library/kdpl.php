<?php
# Library
class kdpl{
	public function designer(){
		return array('Tamilvanan','Arunkumar','Vijayakumar');
	}
}
