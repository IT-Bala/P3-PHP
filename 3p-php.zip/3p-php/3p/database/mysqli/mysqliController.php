<?php
if(!defined('p3')){ die("Access Denied!");}
class mysqliController extends settingError{ # Collections Of MYSQLI query functions
    public $db;
    public function mysqliController(){ 
	        mysqli_report(MYSQLI_REPORT_STRICT);
			$this->db='';
			$pdoArgs = func_get_args(); extract($pdoArgs[0]);
			try {
				$this->db = new mysqli($hostname, $username, $password,$database) or $this->error("Unable to connect with Database");
			} catch (Exception $e) {
				$this->error(ucfirst($e->getMessage()));
			} 
			return $this->db;
	}
	public function dbConnection(){
		 return $this->db;
	}
} 