<?php
class WLT_Model extends WLT_Controller{
}
