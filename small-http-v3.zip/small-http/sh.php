<?php
if(!defined("SHA")) die("Access denied!");
#self::get('/cmd',function($app){ echo $app->json(["Welcome to SH CMD..."]); });

